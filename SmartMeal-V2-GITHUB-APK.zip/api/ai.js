export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.AI_API_KEY;
  if (!key) return res.status(503).json({ error: 'AI service is not configured' });
  const base = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
  const model = process.env.AI_MODEL || 'gpt-4o-mini';
  try {
    const body = req.body || {};
    const prompt = String(body.prompt || '').slice(0, 12000);
    if (!prompt) return res.status(400).json({ error: 'Missing prompt' });
    const r = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        temperature: 0.6,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: 'You are Smart Meal AI. Return only valid JSON. Create practical meal suggestions and macro estimates. Do not diagnose disease or give medical treatment.' },
          { role: 'user', content: prompt }
        ]
      })
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.error?.message || 'AI request failed' });
    const text = data?.choices?.[0]?.message?.content || '{}';
    let parsed;
    try { parsed = JSON.parse(text); } catch { return res.status(502).json({ error: 'AI returned invalid JSON' }); }
    return res.status(200).json(parsed);
  } catch (e) {
    return res.status(500).json({ error: 'AI server error' });
  }
}
